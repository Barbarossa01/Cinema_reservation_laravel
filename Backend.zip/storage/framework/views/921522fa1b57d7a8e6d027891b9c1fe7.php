<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($film->title); ?> - Szczegóły</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <section class="film-details">
            <h1><?php echo e($film->title); ?></h1>
            <img src="<?php echo e($film->image ? asset('images/' . $film->image) : asset('images/placeholder.jpg')); ?>" alt="<?php echo e($film->title); ?>">
            <p><strong>Opis:</strong> <?php echo e($film->description); ?></p>
            <p><strong>Kategoria:</strong> <?php echo e($film->category); ?></p>
            <p><strong>Czas trwania:</strong> <?php echo e(intdiv($film->duration, 60)); ?> godz. <?php echo e($film->duration % 60); ?> min</p>

            <h2>Seanse</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data</th>
                        <th>Godzina</th>
                        <th>Sala</th>
                        <th>Dostępne miejsca</th> 
                        <th>Cena</th> 
                        <th>Akcja</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $screenings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($screening->id); ?></td>
                            <td><?php echo e($screening->date); ?></td>
                            <td><?php echo e($screening->time); ?></td>
                            <td><?php echo e($screening->hall); ?></td>
                            <td><?php echo e($screening->available_seats); ?></td> 
                            <td><?php echo e(number_format($screening->price, 2)); ?> zł</td> 
                            <td>
                                <!-- Reserve Button -->
                                <form action="<?php echo e(route('reservations.create', ['screening' => $screening->id])); ?>" method="GET" style="margin-top: 10px;">
                <button type="submit" class="btn reserve-btn">Zarezerwuj bilet</button>
            </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Kino+ Cinema Network. Wszystkie prawa zastrzeżone.</p>
    </footer>
</body>
</html>
<?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/films/show.blade.php ENDPATH**/ ?>