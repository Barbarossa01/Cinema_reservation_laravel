<header>
    <div class="logo">
        <img src="<?php echo e(asset('images/logo.webp')); ?>" alt="Kino+ Logo">
    </div>
    <nav>
        <ul class="menu">
            <li><a href="<?php echo e(url('/')); ?>">Strona główna</a></li>
            <li><a href="<?php echo e(route('films.index')); ?>">Repertuar</a></li>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin()): ?>
                    <!-- Administrator-only Links -->
                    <li><a href="<?php echo e(route('films.create')); ?>">Dodaj Film</a></li>
                    <li><a href="<?php echo e(route('screenings.index')); ?>">Lista Seansów</a></li>
                    <li><a href="<?php echo e(route('screenings.create')); ?>">Dodaj Seans</a></li>
                    <li><a href="<?php echo e(route('reservations.index')); ?>">Lista Rezerwacji</a></li>
                <?php endif; ?>

                <!-- Moje Konto for All Logged-in Users -->
                <li><a href="<?php echo e(route('user.profile')); ?>">Moje Konto</a></li>

                <!-- Logout Option Styled as Button -->
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-button">Wyloguj</button>
                    </form>
                </li>
            <?php else: ?>
                <!-- Links for Guests -->
                <li><a href="<?php echo e(route('login')); ?>">Zaloguj się</a></li>
                <li><a href="<?php echo e(route('register')); ?>">Zarejestruj się</a></li>
            <?php endif; ?>

            <li><a href="<?php echo e(route('pages.about')); ?>">O nas</a></li>
            <li><a href="<?php echo e(route('pages.contact')); ?>">Kontakt</a></li>
        </ul>
    </nav>
</header>
<?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/layouts/header.blade.php ENDPATH**/ ?>