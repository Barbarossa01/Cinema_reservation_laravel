

<?php $__env->startSection('content'); ?>

<h1>Screenings</h1>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Data</th>
            <th>Czas</th>
            <th>Hala</th>
            <th>Film</th>
            <th>Dostępne miejsca</th>
            <th>Cena</th>
            <th>Typ ekranu</th>
            <th>Akcja</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $screenings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($screening->id); ?></td>
                <td><?php echo e($screening->date); ?></td>
                <td><?php echo e($screening->time); ?></td>
                <td><?php echo e($screening->hall); ?></td>
                <td><?php echo e($screening->film->title); ?></td>
                <td><?php echo e($screening->available_seats); ?></td>
                <td><?php echo e($screening->price); ?></td>
                <td><?php echo e($screening->screen_type); ?></td>
                <td>
                    <?php if(auth()->check() && auth()->user()->isAdmin()): ?>
                        <div class="actions">
                            <a href="<?php echo e(route('screenings.edit', $screening->id)); ?>" class="btn edit-btn">Edytuj</a>
                            <form action="<?php echo e(route('screenings.destroy', $screening->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn delete-btn" onclick="return confirm('Czy na pewno?')">Usuń</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/screenings/index.blade.php ENDPATH**/ ?>