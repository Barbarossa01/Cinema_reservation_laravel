

<?php $__env->startSection('title', 'Moje Rezerwacje'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Moje Rezerwacje</h1>

    <?php if($reservations->isEmpty()): ?>
        <p>Nie masz żadnych aktywnych rezerwacji.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Film</th>
                    <th>Data</th>
                    <th>Godzina</th>
                    <th>Sala</th>
                    <th>Liczba miejsc</th>
                    <th>Akcja</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($reservation->screening->film->title); ?></td>
                        <td><?php echo e($reservation->screening->date); ?></td>
                        <td><?php echo e($reservation->screening->time); ?></td>
                        <td><?php echo e($reservation->screening->hall); ?></td>
                        <td><?php echo e($reservation->seats); ?></td>
                        <td>
                            <!-- Cancel Reservation Button -->
                            <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Czy na pewno chcesz anulować tę rezerwację?')">
                                    Anuluj
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/user/reservations.blade.php ENDPATH**/ ?>