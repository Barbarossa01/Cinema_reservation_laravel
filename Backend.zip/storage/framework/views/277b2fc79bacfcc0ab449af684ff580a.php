

<?php $__env->startSection('title', 'Repertuar'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Filter Section -->
    <section class="filter-section">
        <h1>Repertuar</h1>
        <form class="filter-form">
            <label for="genre">Wybierz gatunek:</label>
            <select id="genre">
                <option value="all">Wszystkie</option>
                <option value="akcja">Akcja</option>
                <option value="komedia">Komedia</option>
                <option value="drama">Drama</option>
                <option value="horror">Horror</option>
            </select>
        </form>
    </section>

    <!-- Movies List -->
    <section class="movies-list" id="movies-list">
        <?php $__empty_1 = true; $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="movie" data-category="<?php echo e(strtolower($film->category)); ?>">
                <img src="<?php echo e($film->image ? asset('images/' . $film->image) : asset('images/placeholder.jpg')); ?>" alt="<?php echo e($film->title); ?>">

                <div class="movie-details">
                    <h2>Film: <span><?php echo e($film->title); ?></span></h2>
                    <p><strong>Gatunek:</strong> <?php echo e(ucfirst($film->category)); ?></p>
                    <p><strong>Czas trwania:</strong> <?php echo e(intdiv($film->duration, 60)); ?> godz. <?php echo e($film->duration % 60); ?> min</p>

                    <?php if(auth()->check() && auth()->user()->isAdmin()): ?>
                        <div class="actions">
                            <a href="<?php echo e(route('films.edit', $film->id)); ?>" class="btn edit-btn">Edytuj</a>
                            <form action="<?php echo e(route('films.destroy', $film->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn delete-btn" onclick="return confirm('Czy na pewno?')">Usuń</button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <!-- Button for Rezerwuj -->
                    <form action="<?php echo e(route('films.show', $film->id)); ?>" method="GET" style="margin-top: 10px;">
                        <button type="submit" class="btn reserve-btn">Rezerwuj</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Brak filmów do wyświetlenia.</p>
        <?php endif; ?>
    </section>

    <!-- JavaScript for Filtering -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const genreFilter = document.getElementById("genre");
            const movies = document.querySelectorAll(".movie");

            // Get unique categories from the movie list
            const categories = new Set(); // Use a Set to ensure uniqueness
            movies.forEach(movie => {
                const category = movie.getAttribute("data-category");
                if (category) {
                    categories.add(category);
                }
            });

            // Populate the genre filter dropdown
            genreFilter.innerHTML = ""; // Clear existing options
            genreFilter.insertAdjacentHTML("beforeend", '<option value="all">Wszystkie</option>');
            categories.forEach(category => {
                genreFilter.insertAdjacentHTML("beforeend", `<option value="${category}">${capitalize(category)}</option>`);
            });

            // Add event listener for filtering movies
            genreFilter.addEventListener("change", function () {
                const selectedGenre = genreFilter.value;

                movies.forEach(movie => {
                    const movieCategory = movie.getAttribute("data-category");
                    if (selectedGenre === "all" || movieCategory === selectedGenre) {
                        movie.style.display = "block"; // Show the movie
                    } else {
                        movie.style.display = "none"; // Hide the movie
                    }
                });
            });

            // Helper function to capitalize the first letter
            function capitalize(str) {
                return str.charAt(0).toUpperCase() + str.slice(1);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/films/index.blade.php ENDPATH**/ ?>