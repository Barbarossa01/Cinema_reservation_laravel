
<?php $__env->startSection('content'); ?>
<h1>Edit Film</h1>
<form method="POST" action="<?php echo e(route('films.update', $film)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <table>
        <tr>
            <td><label for="title">Tytuł:</label></td>
            <td><input type="text" name="title" value="<?php echo e($film->title); ?>" required></td>
        </tr>
        <tr>
            <td><label for="description">Opis:</label></td>
            <td><textarea name="description"><?php echo e($film->description); ?></textarea></td>
        </tr>
        <tr>
            <td><label for="category">Kategoria:</label></td>
            <td><input type="text" name="category" value="<?php echo e($film->category); ?>" required></td>
        </tr>
        <tr>
            <td><label for="duration">Czas trwania (minuty):</label></td>
            <td><input type="number" name="duration" value="<?php echo e($film->duration); ?>" required></td>
        </tr>
        <tr>
            <td><label for="image">Zdjęcie:</label></td>
            <td>
                <input type="file" name="image">
                <?php if($film->image): ?>
                    <img src="<?php echo e(asset('storage/' . $film->image)); ?>" alt="Obraz filmu" width="100">
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="2"><button type="submit">Zapisz zmiany</button></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/films/edit.blade.php ENDPATH**/ ?>