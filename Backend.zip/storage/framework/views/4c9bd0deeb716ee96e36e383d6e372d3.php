

<?php $__env->startSection('title', 'Lista Rezerwacji'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Lista Rezerwacji</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Użytkownik</th>
                <th>Film</th>
                <th>Data</th>
                <th>Godzina</th>
                <th>Miejsca</th>
                <th>Akcja</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($reservation->id); ?></td>
                    <td><?php echo e($reservation->user->email); ?></td>
                    <td><?php echo e($reservation->screening->film->title); ?></td>
                    <td><?php echo e($reservation->screening->date); ?></td>
                    <td><?php echo e($reservation->screening->time); ?></td>
                    <td><?php echo e($reservation->seats); ?></td>
                    <td>
                        <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST" onsubmit="return confirm('Czy na pewno chcesz usunąć tę rezerwację?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn delete-btn">Usuń</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Brak rezerwacji.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/reservations/index.blade.php ENDPATH**/ ?>