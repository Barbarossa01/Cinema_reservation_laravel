

<?php $__env->startSection('content'); ?>

<h1>Dodaj seans</h1>

<!-- Form for Adding a New Screening -->
<form id="screeningForm" action="<?php echo e(route('screenings.store')); ?>" method="POST" class="form-container">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="date">Data:</label>
        <input type="date" name="date" id="date" required>
    </div>

    <div class="form-group">
        <label for="time">Godzina:</label>
        <input type="time" name="time" id="time" required>
    </div>

    <div class="form-group">
        <label for="hall">Hala:</label>
        <input type="text" name="hall" id="hall" required>
    </div>

    <div class="form-group">
        <label for="film_id">Film:</label>
        <select name="film_id" id="film_id" required>
            <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($film->id); ?>"><?php echo e($film->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="available_seats">Dostępne miejsca:</label>
        <input type="number" name="available_seats" id="available_seats" 
               value="<?php echo e(old('available_seats', $defaultSeats ?? 0)); ?>" required>
    </div>

    <div class="form-group">
        <label for="price">Cena:</label>
        <input type="number" step="0.01" name="price" id="price" 
               value="<?php echo e(old('price', $defaultPrice ?? 0.00)); ?>" required>
    </div>

    <div class="form-group">
        <label for="screen_type">Typ ekranu:</label>
        <select name="screen_type" id="screen_type" required>
            <option value="2D" <?php echo e(old('screen_type') == '2D' ? 'selected' : ''); ?>>2D</option>
            <option value="3D" <?php echo e(old('screen_type') == '3D' ? 'selected' : ''); ?>>3D</option>
            <option value="IMAX" <?php echo e(old('screen_type') == 'IMAX' ? 'selected' : ''); ?>>IMAX</option>
        </select>
    </div>

    <div class="form-actions">
        <button type="submit" class="btn submit-btn">Dodaj seans</button>
        <a href="<?php echo e(route('screenings.index')); ?>" class="btn cancel-btn">Powrót do seansów</a>
    </div>
</form>

<script>
    document.getElementById('screeningForm').addEventListener('submit', function(event) {
        const dateInput = document.getElementById('date').value;
        const today = new Date();
        const selectedDate = new Date(dateInput);

        // Calculate the maximum date (1 year from today)
        const maxDate = new Date();
        maxDate.setFullYear(today.getFullYear() + 1);

        // Check if the selected date is in the future
        if (selectedDate <= today) {
            alert('Data musi być w przyszłości.');
            event.preventDefault(); // Prevent form submission
            return;
        }

        // Check if the selected date is within one year
        if (selectedDate > maxDate) {
            alert('Data nie może być późniejsza niż jeden rok od dzisiaj.');
            event.preventDefault(); // Prevent form submission
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/screenings/create.blade.php ENDPATH**/ ?>