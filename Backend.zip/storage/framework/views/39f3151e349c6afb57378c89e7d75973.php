<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel użytkownika</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <section class="user-panel">
            <h1>Panel użytkownika</h1>

            <div class="reservation-history">
                <h2>Historia rezerwacji</h2>

                <?php if($reservations->count()): ?>
                    <table class="reservation-table">
                        <thead>
                            <tr>
                                <th>Film</th>
                                <th>Data</th>
                                <th>Godzina</th>
                                <th>Sala</th>
                                <th>Ilość miejsc</th>
                                <th>Akcja</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($reservation->screening->film->title); ?></td>
                                    <td><?php echo e($reservation->screening->date); ?></td>
                                    <td><?php echo e($reservation->screening->time); ?></td>
                                    <td><?php echo e($reservation->screening->hall); ?></td>
                                    <td><?php echo e($reservation->seats); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('Czy na pewno chcesz usunąć tę rezerwację?')">
                                                Anuluj Rezerwację
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Brak rezerwacji do wyświetlenia.</p>
                <?php endif; ?>
            </div>

            <!-- Edit User Details -->
            <div class="edit-details">
                <h2>Edycja danych</h2>
                <form method="POST" action="<?php echo e(route('user.profile.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>

                    <label for="email">E-mail:</label>
                    <input type="email" id="email" name="email" value="<?php echo e($user->email); ?>" required>

                    <label for="password">Hasło:</label>
                    <input type="password" id="password" name="password" placeholder="Zmień hasło">

                    <label for="first_name">Imię:</label>
                    <input type="text" id="first_name" name="first_name" value="<?php echo e($user->first_name); ?>" required>

                    <label for="last_name">Nazwisko:</label>
                    <input type="text" id="last_name" name="last_name" value="<?php echo e($user->last_name); ?>" required>

                    <button type="submit">Zapisz zmiany</button>
                </form>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Kino+ Cinema Network. Wszystkie prawa zastrzeżone.</p>
    </footer>
</body>
</html>
<?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/user/profile.blade.php ENDPATH**/ ?>