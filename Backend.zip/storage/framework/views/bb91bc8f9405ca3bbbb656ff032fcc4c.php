

<?php $__env->startSection('content'); ?>
<div class="reservation-container">
    <h1 class="reservation-title">
        Zarezerwuj miejsca na <span class="film-title"><?php echo e($screening->film->title); ?></span>
    </h1>

    <form action="<?php echo e(route('reservations.store', $screening->id)); ?>" method="POST" class="reservation-form">
        <?php echo csrf_field(); ?>

        <table class="reservation-table">
            <tr>
                <td class="form-label">
                    <label for="seats">Liczba miejsc:</label>
                </td>
                <td>
                    <input 
                        type="number" 
                        name="seats" 
                        id="seats" 
                        class="form-input" 
                        min="1" 
                        max="<?php echo e($screening->available_seats); ?>" 
                        placeholder="Wybierz liczbę miejsc" 
                        required>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="form-actions">
                    <button type="submit" class="btn btn-primary">Zarezerwuj teraz</button>
                    <a href="<?php echo e(route('films.index')); ?>" class="btn btn-secondary">Powrót do filmów</a>
                </td>
            </tr>
        </table>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/reservations/create.blade.php ENDPATH**/ ?>