

<?php $__env->startSection('content'); ?>
<h1>Edytuj seans</h1>
<form method="POST" action="<?php echo e(route('screenings.update', $screening->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="date">Data:</label>
    <input type="date" id="date" name="date" value="<?php echo e(old('date', $screening->date)); ?>" required>

    <label for="time">Godzina:</label>
    <input type="time" id="time" name="time" value="<?php echo e(old('time', $screening->time)); ?>" required>

    <label for="hall">Hala:</label>
    <input type="text" id="hall" name="hall" value="<?php echo e(old('hall', $screening->hall)); ?>" required>

    <label for="film_id">Film:</label>
    <select id="film_id" name="film_id" required>
        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($film->id); ?>" <?php echo e(old('film_id', $screening->film_id) == $film->id ? 'selected' : ''); ?>>
                <?php echo e($film->title); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="available_seats">Dostępne miejsca:</label>
    <input type="number" id="available_seats" name="available_seats" value="<?php echo e(old('available_seats', $screening->available_seats)); ?>" required>

    <label for="price">Cena:</label>
    <input type="number" step="0.01" id="price" name="price" value="<?php echo e(old('price', $screening->price)); ?>" required>

    <label for="screen_type">Typ ekranu:</label>
    <select id="screen_type" name="screen_type" required>
        <option value="2D" <?php echo e(old('screen_type', $screening->screen_type) == '2D' ? 'selected' : ''); ?>>2D</option>
        <option value="3D" <?php echo e(old('screen_type', $screening->screen_type) == '3D' ? 'selected' : ''); ?>>3D</option>
        <option value="IMAX" <?php echo e(old('screen_type', $screening->screen_type) == 'IMAX' ? 'selected' : ''); ?>>IMAX</option>
    </select>

    <button type="submit">Zapisz zmiany</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/screenings/edit.blade.php ENDPATH**/ ?>