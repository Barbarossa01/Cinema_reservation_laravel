

<?php $__env->startSection('content'); ?>
<h1>Rezerwacja zakończona sukcesem!</h1>
<p>Twoje bilety zostały zarezerwowane. Prosimy o dokonanie płatności w kasie kina.</p>

<a href="<?php echo e(route('films.index')); ?>" class="btn submit-btn">Powrót do Filmów</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/s49597/public_html/cinema-reservation/resources/views/reservations/success.blade.php ENDPATH**/ ?>